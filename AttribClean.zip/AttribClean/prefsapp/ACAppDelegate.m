// ACAppDelegate.m
#import "ACAppDelegate.h"
#import "ACListViewController.h"

@implementation ACAppDelegate

- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];

    ACListViewController *root = [[ACListViewController alloc] initWithStyle:UITableViewStyleInsetGrouped];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:root];

    if (@available(iOS 13.0, *)) {
        nav.navigationBar.prefersLargeTitles = YES;
    }

    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
