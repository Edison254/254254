// ACAppEnumerator.m
#import "ACAppEnumerator.h"

static NSString *const kAppBundleBase = @"/var/containers/Bundle/Application";
static NSString *const kAppDataBase   = @"/var/mobile/Containers/Data/Application";

@implementation ACAppInfo
- (NSString *)description {
    return [NSString stringWithFormat:@"<%@ %@>", self.name, self.bundleID];
}
@end

@interface ACAppEnumerator ()
+ (UIImage *)iconForAppAtPath:(NSString *)appPath info:(NSDictionary *)info;
@end

@implementation ACAppEnumerator

#pragma mark - 数据容器

+ (NSDictionary<NSString *, NSString *> *)dataContainerMap {
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    NSFileManager *fm = [NSFileManager defaultManager];

    NSArray<NSString *> *dirs = [fm contentsOfDirectoryAtPath:kAppDataBase error:NULL];
    if (!dirs) return map;

    for (NSString *uuid in dirs) {
        @autoreleasepool {
            NSString *container = [kAppDataBase stringByAppendingPathComponent:uuid];
            NSString *metaPath = [container stringByAppendingPathComponent:
                                  @".com.apple.mobile_container_manager.metadata.plist"];

            NSDictionary *meta = [NSDictionary dictionaryWithContentsOfFile:metaPath];
            if (![meta isKindOfClass:[NSDictionary class]]) continue;

            NSString *bid = meta[@"MCMMetadataIdentifier"];
            if ([bid isKindOfClass:[NSString class]] && bid.length) {
                map[bid] = container;
            }
        }
    }
    return map;
}

#pragma mark - 应用列表

+ (NSArray<ACAppInfo *> *)installedApps {
    NSMutableArray<ACAppInfo *> *result = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];

    NSDictionary *dataMap = [self dataContainerMap];

    NSArray<NSString *> *containers = [fm contentsOfDirectoryAtPath:kAppBundleBase error:NULL];
    if (!containers) return result;

    for (NSString *containerUUID in containers) {
        @autoreleasepool {
            NSString *containerPath = [kAppBundleBase stringByAppendingPathComponent:containerUUID];
            NSArray<NSString *> *entries = [fm contentsOfDirectoryAtPath:containerPath error:NULL];

            for (NSString *entry in entries) {
                if (![entry hasSuffix:@".app"]) continue;

                NSString *appPath = [containerPath stringByAppendingPathComponent:entry];
                NSString *infoPath = [appPath stringByAppendingPathComponent:@"Info.plist"];
                NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:infoPath];
                if (![info isKindOfClass:[NSDictionary class]]) continue;

                NSString *bid = info[@"CFBundleIdentifier"];
                if (![bid isKindOfClass:[NSString class]] || bid.length == 0) continue;

                // 跳过系统 App 与本程序自身
                if ([bid hasPrefix:@"com.apple."]) continue;
                if ([bid isEqualToString:@"com.zaka.attribcleanprefs"]) continue;

                ACAppInfo *a = [ACAppInfo new];
                a.bundleID = bid;
                a.bundlePath = appPath;

                NSString *display = info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"] ?: entry;
                a.name = [display isKindOfClass:[NSString class]] ? display : entry;

                a.dataPath = dataMap[bid];
                a.icon = [self iconForAppAtPath:appPath info:info];

                [result addObject:a];
            }
        }
    }

    [result sortUsingComparator:^NSComparisonResult(ACAppInfo *a, ACAppInfo *b) {
        return [a.name localizedStandardCompare:b.name];
    }];

    return result;
}

#pragma mark - 图标

+ (UIImage *)iconForAppAtPath:(NSString *)appPath info:(NSDictionary *)info {
    @try {
        // 1) 通过 bundle 取名（iOS 10+ 常用方式）
        NSBundle *b = [NSBundle bundleWithPath:appPath];
        if (b) {
            NSArray *names = info[@"CFBundleIcons"][@"CFBundlePrimaryIcon"][@"CFBundleIconFiles"];
            if (![names isKindOfClass:[NSArray class]] || names.count == 0) {
                names = info[@"CFBundleIconFiles"];
            }
            for (NSInteger i = (NSInteger)names.count - 1; i >= 0; i--) {
                id n = names[i];
                if (![n isKindOfClass:[NSString class]]) continue;
                UIImage *img = [UIImage imageNamed:n inBundle:b compatibleWithTraitCollection:nil];
                if (img) return img;
            }
        }

        // 2) 目录里找 AppIcon 开头最大的一张
        NSArray<NSString *> *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:appPath error:NULL];
        NSMutableArray<NSString *> *cands = [NSMutableArray array];
        for (NSString *f in files) {
            NSString *low = [f lowercaseString];
            if ([low hasPrefix:@"appicon"] && [low hasSuffix:@".png"]) {
                [cands addObject:f];
            }
        }
        // 尺寸大的一般文件名里带更大的数字，简单倒序取第一个
        [cands sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            return [b compare:a];
        }];
        for (NSString *f in cands) {
            UIImage *img = [UIImage imageWithContentsOfFile:[appPath stringByAppendingPathComponent:f]];
            if (img) return img;
        }
    } @catch (__unused NSException *e) {}
    return nil;
}

@end
