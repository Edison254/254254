// ACAppEnumerator.h — 枚举已安装 App 与其数据容器
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ACAppInfo : NSObject
@property (nonatomic, copy)   NSString *bundleID;
@property (nonatomic, copy)   NSString *name;
@property (nonatomic, copy)   NSString *bundlePath;
@property (nonatomic, copy)   NSString *dataPath;
@property (nonatomic, strong) UIImage  *icon;
@end

@interface ACAppEnumerator : NSObject

/// 所有用户安装的 App（按名字排序），耗时操作，请在后台线程调用
+ (NSArray<ACAppInfo *> *)installedApps;

/// bundleID -> 数据容器路径
+ (NSDictionary<NSString *, NSString *> *)dataContainerMap;

@end
