// ACIdentity.m — IDFA / IDFV 虚拟标识
#import "ACIdentity.h"
#import "ACCommon.h"
#import "ACPrefs.h"

static NSString *gIDFACache = nil;

@implementation ACIdentity

#pragma mark - 生成

+ (NSString *)generateIDFA {
    // IDFA 格式：8-4-4-4-12 的大写 UUID
    CFUUIDRef uuid = CFUUIDCreate(kCFAllocatorDefault);
    NSString *s = CFBridgingRelease(CFUUIDCreateString(kCFAllocatorDefault, uuid));
    CFRelease(uuid);
    return [s uppercaseString];
}

+ (NSString *)generateIDFV {
    return [self generateIDFA];
}

+ (NSString *)vendorKeyForBundleID:(NSString *)bundleID {
    if (!bundleID || bundleID.length == 0) return @"unknown";
    NSArray *parts = [bundleID componentsSeparatedByString:@"."];
    if (parts.count >= 2) {
        return [NSString stringWithFormat:@"%@.%@", parts[0], parts[1]];
    }
    return bundleID;
}

#pragma mark - 读取

+ (NSString *)fakeIDFA {
    @try {
        if (gIDFACache) return gIDFACache;

        NSDictionary *cfg = [ACPrefs currentConfig];
        NSString *v = cfg[kACKeyFakeIDFA];
        if ([v isKindOfClass:[NSString class]] && v.length == 36) {
            gIDFACache = [v uppercaseString];
            return gIDFACache;
        }

        // 没配就现造一个并写回容器配置，保证同一 App 每次一致
        NSString *fresh = [self generateIDFA];
        NSMutableDictionary *local = [NSMutableDictionary dictionary];
        NSDictionary *exist = [NSDictionary dictionaryWithContentsOfFile:ACLocalPrefsPath()];
        if ([exist isKindOfClass:[NSDictionary class]]) [local addEntriesFromDictionary:exist];
        local[kACKeyFakeIDFA] = fresh;
        [ACPrefs writeLocalConfig:local];

        gIDFACache = fresh;
        return gIDFACache;
    } @catch (__unused NSException *e) {
        return nil;
    }
}

+ (NSString *)fakeIDFVForBundleID:(NSString *)bundleID {
    @try {
        NSString *vendor = [self vendorKeyForBundleID:bundleID];

        NSDictionary *cfg = [ACPrefs currentConfig];
        NSDictionary *map = cfg[kACKeyIDFVMap];
        if ([map isKindOfClass:[NSDictionary class]]) {
            NSString *v = map[vendor];
            if ([v isKindOfClass:[NSString class]] && v.length == 36) {
                return [v uppercaseString];
            }
        }

        NSString *fresh = [self generateIDFV];
        NSMutableDictionary *local = [NSMutableDictionary dictionary];
        NSDictionary *exist = [NSDictionary dictionaryWithContentsOfFile:ACLocalPrefsPath()];
        if ([exist isKindOfClass:[NSDictionary class]]) [local addEntriesFromDictionary:exist];

        NSMutableDictionary *newMap = [NSMutableDictionary dictionary];
        if ([map isKindOfClass:[NSDictionary class]]) [newMap addEntriesFromDictionary:map];
        newMap[vendor] = fresh;
        local[kACKeyIDFVMap] = newMap;
        [ACPrefs writeLocalConfig:local];

        return fresh;
    } @catch (__unused NSException *e) {
        return nil;
    }
}

+ (void)invalidateCache {
    gIDFACache = nil;
}

@end
