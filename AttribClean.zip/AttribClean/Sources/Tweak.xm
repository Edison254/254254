// Tweak.xm — 注入主入口
//
// 设计原则（防止闪退）：
//   1. 只在【用户 App】进程内工作，系统进程 / 守护进程一律直接退出
//   2. 所有 hook 内部都包 @try/@catch，任何异常都退回原实现
//   3. 所有类 / 方法在使用前判空，不存在就跳过，绝不强行 hook
//   4. 文件操作全部在后台队列，不阻塞主线程
//   5. 清理只删命中的文件名，不碰 App 主配置整体

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dlfcn.h>

#import <AdSupport/AdSupport.h>
#import <AppTrackingTransparency/AppTrackingTransparency.h>

#import "ACCommon.h"
#import "ACPrefs.h"
#import "ACIdentity.h"
#import "ACCleaner.h"
#import "ACLog.h"

#pragma mark - 运行时判断

static BOOL ACShouldFakeIDFA(void) {
    @try {
        return [ACPrefs boolForKey:kACKeyEnabled] && [ACPrefs boolForKey:kACKeyCleanIDFA];
    } @catch (__unused NSException *e) {
        return NO;
    }
}

static BOOL ACShouldFakeIDFV(void) {
    @try {
        return [ACPrefs boolForKey:kACKeyEnabled] && [ACPrefs boolForKey:kACKeyCleanIDFV];
    } @catch (__unused NSException *e) {
        return NO;
    }
}

static BOOL ACShouldFakeATT(void) {
    @try {
        return [ACPrefs boolForKey:kACKeyEnabled] && [ACPrefs boolForKey:kACKeyCleanATT];
    } @catch (__unused NSException *e) {
        return NO;
    }
}

#pragma mark - IDFA

%group ACIDFAGroup

%hook ASIdentifierManager

- (NSUUID *)advertisingIdentifier {
    if (ACShouldFakeIDFA()) {
        @try {
            NSString *fake = [ACIdentity fakeIDFA];
            if (fake.length == 36) {
                NSUUID *u = [[NSUUID alloc] initWithUUIDString:fake];
                if (u) return u;
            }
        } @catch (__unused NSException *e) {}
    }
    return %orig;
}

%end

%end

#pragma mark - IDFV

%group ACIDFVGroup

%hook UIDevice

- (NSUUID *)identifierForVendor {
    if (ACShouldFakeIDFV()) {
        @try {
            NSString *fake = [ACIdentity fakeIDFVForBundleID:[[NSBundle mainBundle] bundleIdentifier]];
            if (fake.length == 36) {
                NSUUID *u = [[NSUUID alloc] initWithUUIDString:fake];
                if (u) return u;
            }
        } @catch (__unused NSException *e) {}
    }
    return %orig;
}

%end

%end

#pragma mark - ATT

%group ACATTGroup

%hook ATTrackingManager

+ (ATTrackingManagerAuthorizationStatus)trackingAuthorizationStatus {
    if (ACShouldFakeATT()) {
        @try { return ATTrackingManagerAuthorizationStatusAuthorized; }
        @catch (__unused NSException *e) {}
    }
    return %orig;
}

+ (void)requestTrackingAuthorizationWithCompletionHandler:(void (^)(ATTrackingManagerAuthorizationStatus))completion {
    if (ACShouldFakeATT()) {
        @try {
            if (completion) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    @try { completion(ATTrackingManagerAuthorizationStatusAuthorized); }
                    @catch (__unused NSException *e) {}
                });
                return;
            }
        } @catch (__unused NSException *e) {}
    }
    %orig;
}

%end

%end

#pragma mark - 清理调度

static void ACScheduleClean(NSDictionary *cfg) {
    if (![cfg isKindOfClass:[NSDictionary class]]) return;

    // 第一轮：尽早清，尽量赶在 SDK 读数据之前
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        @autoreleasepool {
            @try { [ACCleaner cleanCurrentAppWithConfig:cfg]; }
            @catch (__unused NSException *e) {}
        }
    });

    // 第二轮：3 秒后再补一次，处理 SDK 启动过程中新写出来的
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
                   dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool {
            @try { [ACCleaner cleanCurrentAppWithConfig:cfg]; }
            @catch (__unused NSException *e) {}
        }
    });
}

#pragma mark - 入口

%ctor {
    @autoreleasepool {
        @try {
            // 只处理用户 App，系统进程到此为止
            if (!ACIsUserApp()) return;

            NSDictionary *cfg = [ACPrefs currentConfig];
            if (![cfg isKindOfClass:[NSDictionary class]]) return;
            if (![cfg[kACKeyEnabled] boolValue]) return;

            // 1) IDFA（按需加载 AdSupport，未开启就不加载）
            if ([cfg[kACKeyCleanIDFA] boolValue]) {
                @try {
                    dlopen("/System/Library/Frameworks/AdSupport.framework/AdSupport", RTLD_LAZY);
                    if (NSClassFromString(@"ASIdentifierManager")) {
                        %init(ACIDFAGroup);
                    }
                } @catch (__unused NSException *e) {}
            }

            // 2) IDFV
            if ([cfg[kACKeyCleanIDFV] boolValue]) {
                @try {
                    if (NSClassFromString(@"UIDevice")) {
                        %init(ACIDFVGroup);
                    }
                } @catch (__unused NSException *e) {}
            }

            // 3) ATT
            if ([cfg[kACKeyCleanATT] boolValue]) {
                @try {
                    dlopen("/System/Library/Frameworks/AppTrackingTransparency.framework/AppTrackingTransparency", RTLD_LAZY);
                    if (NSClassFromString(@"ATTrackingManager")) {
                        %init(ACATTGroup);
                    }
                } @catch (__unused NSException *e) {}
            }

            // 4) 归因数据清理
            ACScheduleClean(cfg);

        } @catch (NSException *e) {
            // 任何意外都静默退出，绝不向上抛
        }
    }
}
