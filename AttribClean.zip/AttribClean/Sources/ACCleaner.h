// ACCleaner.h — 归因数据清理核心
#import <Foundation/Foundation.h>

@interface ACCleaner : NSObject

/// 按当前配置清理当前进程所在 App 的归因数据。异步安全，可重复调用。
+ (void)cleanCurrentAppWithConfig:(NSDictionary *)cfg;

/// 只做检测，返回会命中的路径（给预演模式 / 设置界面看）
+ (NSArray<NSString *> *)scanCurrentApp;

@end
