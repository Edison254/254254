// ACCleaner.m — 归因数据清理核心
#import "ACCleaner.h"
#import "ACCommon.h"
#import "ACPrefs.h"
#import "ACLog.h"
#import <Security/Security.h>

#pragma mark - 关键词表

/// 常规模式：只认各归因 / 广告 / 统计 SDK 的品牌名，误伤面最小
static NSArray<NSString *> *ACBrandKeywords(void) {
    static NSArray *a;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        a = @[
            // 归因
            @"appsflyer", @"adjust", @"branch", @"kochava", @"singular",
            @"tenjin", @"appmetrica", @"applink", @"deeplink",
            // Meta
            @"facebook", @"fbsdk", @"fb_sdk", @"fbanalytics", @"fbsdkcorekit", @"fbapplink",
            // 字节
            @"bytedance", @"toutiao", @"bdinstall", @"applog", @"pangle",
            // 腾讯
            @"tencent", @"bugly", @"gdt", @"msdk", @"bugrly",
            // 友盟 / 阿里
            @"umeng", @"alibc", @"aliapp",
            // 快手
            @"kuaishou", @"kwai",
            // 广告聚合
            @"unityads", @"vungle", @"ironsource", @"applovin", @"admob",
            @"chartboost", @"mopub", @"mintegral", @"tapjoy", @"fyber",
            @"smaato", @"inmobi", @"adcolony", @"admost", @"adfit",
            // 统计分析
            @"firebase", @"googleanalytics", @"google_analytics", @"amplitude",
            @"mixpanel", @"mparticle", @"countly", @"smartlook", @"appsee",
            @"crashlytics", @"sentry", @"bugsnag", @"newrelic", @"datadog",
            // 推送（也带 install id）
            @"onesignal", @"jpush", @"getui", @"xgpush", @"umengpush",
        ];
    });
    return a;
}

/// 激进模式：名字里带这些的也算，覆盖更广但可能误伤 App 自己的缓存
static NSArray<NSString *> *ACDeepKeywords(void) {
    static NSArray *a;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        a = @[
            @"segment", @"attribution", @"installid", @"install_id",
            @"idfa", @"idfv", @"gaid", @"oaid", @"aaid",
            @"deviceid", @"device_id", @"device-id",
            @"advertise", @"advertising", @"tracking_id", @"trackid",
        ];
    });
    return a;
}

static BOOL ACNameMatches(NSString *name, BOOL deep) {
    if (![name isKindOfClass:[NSString class]] || name.length == 0) return NO;
    NSString *low = [name lowercaseString];

    // 自己的东西绝不碰
    if ([low hasPrefix:@"com.zaka.attribclean"]) return NO;
    if ([low hasPrefix:@"com.apple"]) return NO;

    for (NSString *k in ACBrandKeywords()) {
        if ([low containsString:k]) return YES;
    }
    if (deep) {
        for (NSString *k in ACDeepKeywords()) {
            if ([low containsString:k]) return YES;
        }
    }
    return NO;
}

#pragma mark - 私有声明

@interface ACCleaner ()
+ (NSMutableArray<NSString *> *)hitsInHome:(NSString *)home deep:(BOOL)deep limit:(NSUInteger)limit;
+ (void)walk:(NSString *)dir
       depth:(NSInteger)depth
    maxDepth:(NSInteger)maxDepth
        deep:(BOOL)deep
    skipPath:(NSString *)skipPath
     ownPath:(NSString *)ownPath
        hits:(NSMutableArray *)hits
       limit:(NSUInteger)limit
          fm:(NSFileManager *)fm;
+ (void)cleanFilesInHome:(NSString *)home deep:(BOOL)deep dry:(BOOL)dry;
+ (void)cleanPreferencesForBundle:(NSString *)bid deep:(BOOL)deep dry:(BOOL)dry;
+ (void)cleanKeychain:(BOOL)deep dry:(BOOL)dry;
+ (NSUInteger)bumpCrashGuard;
+ (void)finishCrashGuard;
@end

#pragma mark - 主体

@implementation ACCleaner

#pragma mark 扫描

+ (NSArray<NSString *> *)scanCurrentApp {
    @try {
        NSDictionary *cfg = [ACPrefs currentConfig];
        BOOL deep = [cfg[kACKeyDeepClean] boolValue];
        return [self hitsInHome:NSHomeDirectory() deep:deep limit:3000];
    } @catch (__unused NSException *e) {
        return @[];
    }
}

+ (NSMutableArray<NSString *> *)hitsInHome:(NSString *)home deep:(BOOL)deep limit:(NSUInteger)limit {
    NSMutableArray *hits = [NSMutableArray array];
    if (!home) return hits;

    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *prefsDir = [home stringByAppendingPathComponent:@"Library/Preferences"];
    NSString *ownDir   = [home stringByAppendingPathComponent:@"Library/Caches/com.zaka.attribclean"];

    NSMutableArray<NSString *> *roots = [NSMutableArray array];
    for (NSString *rel in @[@"Library", @"Documents", @"tmp"]) {
        NSString *p = [home stringByAppendingPathComponent:rel];
        if ([fm fileExistsAtPath:p]) [roots addObject:p];
    }

    for (NSString *root in roots) {
        [self walk:root depth:0 maxDepth:5 deep:deep
           skipPath:prefsDir ownPath:ownDir
              hits:hits limit:limit fm:fm];
        if (hits.count >= limit) break;
    }
    return hits;
}

+ (void)walk:(NSString *)dir
       depth:(NSInteger)depth
    maxDepth:(NSInteger)maxDepth
        deep:(BOOL)deep
    skipPath:(NSString *)skipPath
     ownPath:(NSString *)ownPath
        hits:(NSMutableArray *)hits
       limit:(NSUInteger)limit
          fm:(NSFileManager *)fm {

    if (depth > maxDepth || hits.count >= limit) return;
    if (!dir) return;
    if (skipPath && [dir hasPrefix:skipPath]) return;
    if (ownPath && [dir hasPrefix:ownPath]) return;

    NSArray<NSURL *> *items = [fm contentsOfDirectoryAtURL:[NSURL fileURLWithPath:dir]
                               includingPropertiesForKeys:@[NSURLIsSymbolicLinkKey, NSURLIsDirectoryKey]
                                                  options:NSDirectoryEnumerationSkipsHiddenFiles
                                                    error:NULL];
    if (!items) return;

    for (NSURL *u in items) {
        if (hits.count >= limit) return;

        @autoreleasepool {
            NSString *path = u.path;
            NSString *name = u.lastPathComponent;
            if (!path || !name) continue;

            NSNumber *isLink = nil;
            [u getResourceValue:&isLink forKey:NSURLIsSymbolicLinkKey error:NULL];
            if ([isLink boolValue]) continue;   // 不跟符号链接

            if (ACNameMatches(name, deep)) {
                [hits addObject:path];
                continue;                        // 命中就整棵删，不再往里走
            }

            NSNumber *isDir = nil;
            [u getResourceValue:&isDir forKey:NSURLIsDirectoryKey error:NULL];
            if ([isDir boolValue]) {
                [self walk:path depth:depth + 1 maxDepth:maxDepth deep:deep
                  skipPath:skipPath ownPath:ownPath hits:hits limit:limit fm:fm];
            }
        }
    }
}

#pragma mark 清理

+ (void)cleanCurrentAppWithConfig:(NSDictionary *)cfg {
    if (![cfg isKindOfClass:[NSDictionary class]]) return;

    BOOL dry = [cfg[kACKeyDryRun] boolValue];
    BOOL deep = [cfg[kACKeyDeepClean] boolValue];

    NSString *home = NSHomeDirectory();
    NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"unknown";
    NSString *tag = dry ? @"[预演] " : @"";

    ACLogReset();
    ACLogFmt(@"开始清理 %@（%@）%@", bid, home, dry ? @"预演模式，不实际删除" : @"");
    if (deep) ACLogFmt(@"已开启深度清理");

    // 0) 崩溃熔断检测
    NSUInteger failCount = [self bumpCrashGuard];
    if (failCount >= 5) {
        ACLogFmt(@"连续 %lu 次清理没跑完，这个 App 的自动清理已暂停。", (unsigned long)failCount);
        ACLogFmt(@"到设置里把这个 App 的开关关掉再打开，就能恢复。");
        ACLogFlush();
        return;
    }

    @try {
        // 1) 文件与目录
        if ([cfg[kACKeyCleanFiles] boolValue]) {
            [self cleanFilesInHome:home deep:deep dry:dry];
        }

        // 2) Preferences
        if ([cfg[kACKeyCleanPrefs] boolValue]) {
            [self cleanPreferencesForBundle:bid deep:deep dry:dry];
        }

        // 3) Keychain
        if ([cfg[kACKeyCleanKeychain] boolValue]) {
            [self cleanKeychain:deep dry:dry];
        }
    } @catch (NSException *e) {
        ACLogFmt(@"清理过程中出现异常，已忽略：%@", e.reason ?: @"unknown");
    }

    // 收尾：标记本次正常完成
    [self finishCrashGuard];
    ACLogFmt(@"清理结束%@", dry ? @"（预演）" : @"");
    ACLogFlush();
}

#pragma mark 文件

+ (void)cleanFilesInHome:(NSString *)home deep:(BOOL)deep dry:(BOOL)dry {
    NSArray<NSString *> *hits = [self hitsInHome:home deep:deep limit:3000];
    ACLogFmt(@"匹配到 %lu 项文件/目录", (unsigned long)hits.count);

    if (hits.count == 0) return;

    NSFileManager *fm = [NSFileManager defaultManager];
    NSUInteger okCount = 0, failCount = 0;

    for (NSString *p in hits) {
        @autoreleasepool {
            @try {
                NSString *rel = [p stringByReplacingOccurrencesOfString:home withString:@""];
                if (dry) {
                    ACLogFmt(@"[预演] 会删除 %@", rel);
                    okCount++;
                    continue;
                }
                NSError *err = nil;
                if ([fm removeItemAtPath:p error:&err]) {
                    okCount++;
                    if (okCount <= 60) ACLogFmt(@"删除 %@", rel);
                } else {
                    failCount++;
                }
            } @catch (__unused NSException *e) {
                failCount++;
            }
        }
    }

    if (!dry && okCount > 60) {
        ACLogFmt(@"… 其余 %lu 项已删除", (unsigned long)(okCount - 60));
    }
    ACLogFmt(@"文件清理完成：成功 %lu，失败 %lu",
             (unsigned long)okCount, (unsigned long)failCount);
}

#pragma mark 偏好设置

+ (void)cleanPreferencesForBundle:(NSString *)bid deep:(BOOL)deep dry:(BOOL)dry {
    NSString *prefsDir = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences"];
    NSFileManager *fm = [NSFileManager defaultManager];

    NSArray<NSString *> *files = [fm contentsOfDirectoryAtPath:prefsDir error:NULL];
    if (!files) return;

    NSUInteger removedFiles = 0, scrubbedKeys = 0;

    for (NSString *name in files) {
        @autoreleasepool {
            if (![name hasSuffix:@".plist"]) continue;
            if ([name hasPrefix:@"com.apple"]) continue;
            if ([name hasPrefix:@"com.zaka.attribclean"]) continue;

            NSString *full = [prefsDir stringByAppendingPathComponent:name];
            NSString *domain = [name stringByDeletingPathExtension];

            @try {
                // A) SDK 自己的 domain 文件：整删
                if (ACNameMatches(domain, deep)) {
                    if (dry) {
                        ACLogFmt(@"[预演] 会删除偏好文件 %@", name);
                    } else {
                        NSError *err = nil;
                        if ([fm removeItemAtPath:full error:&err]) removedFiles++;
                    }
                    continue;
                }

                // B) App 主 domain：只删命中的 key，不整文件删
                if ([domain isEqualToString:bid]) {
                    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:full];
                    if (![dict isKindOfClass:[NSDictionary class]] || dict.count == 0) continue;

                    NSMutableDictionary *keep = [NSMutableDictionary dictionaryWithCapacity:dict.count];
                    NSMutableArray *dropped = [NSMutableArray array];

                    for (id key in dict) {
                        NSString *ks = [key isKindOfClass:[NSString class]]
                                     ? (NSString *)key
                                     : [key description];
                        if (ACNameMatches(ks, deep)) {
                            [dropped addObject:ks];
                        } else {
                            keep[key] = dict[key];
                        }
                    }

                    if (dropped.count == 0) continue;
                    scrubbedKeys += dropped.count;

                    NSString *joined = [dropped componentsJoinedByString:@", "];
                    if (joined.length > 200) {
                        joined = [[joined substringToIndex:200] stringByAppendingString:@"…"];
                    }
                    ACLogFmt(@"%@主配置中移除 %lu 个键：%@",
                             dry ? @"[预演] " : @"",
                             (unsigned long)dropped.count,
                             joined);

                    if (!dry) {
                        [keep writeToFile:full atomically:YES];
                    }
                }
            } @catch (__unused NSException *e) {}
        }
    }

    ACLogFmt(@"偏好清理完成：删除文件 %lu，清理键 %lu",
             (unsigned long)removedFiles, (unsigned long)scrubbedKeys);
}

#pragma mark Keychain

+ (void)cleanKeychain:(BOOL)deep dry:(BOOL)dry {
    NSUInteger removed = 0;

    NSArray *classes = @[ (__bridge NSString *)kSecClassGenericPassword,
                          (__bridge NSString *)kSecClassInternetPassword ];

    for (NSString *cls in classes) {
        @autoreleasepool {
            @try {
                NSDictionary *query = @{
                    (__bridge id)kSecClass            : cls,
                    (__bridge id)kSecReturnAttributes : @YES,
                    (__bridge id)kSecMatchLimit       : (__bridge id)kSecMatchLimitAll,
                };

                CFTypeRef result = NULL;
                OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
                if (status != errSecSuccess || !result) {
                    if (result) { CFRelease(result); result = NULL; }
                    if (status != errSecItemNotFound) {
                        ACLogFmt(@"读取钥匙串返回状态 %d（已跳过）", (int)status);
                    }
                    continue;
                }

                NSArray *items = (__bridge_transfer NSArray *)result;
                if (![items isKindOfClass:[NSArray class]]) continue;

                for (NSDictionary *item in items) {
                    @autoreleasepool {
                        if (![item isKindOfClass:[NSDictionary class]]) continue;

                        id svcObj  = item[(__bridge id)kSecAttrService];
                        id acctObj = item[(__bridge id)kSecAttrAccount];
                        id labelObj = item[(__bridge id)kSecAttrLabel];

                        NSString *svc   = [svcObj isKindOfClass:[NSString class]] ? svcObj : @"";
                        NSString *acct  = [acctObj isKindOfClass:[NSString class]] ? acctObj : @"";
                        NSString *label = [labelObj isKindOfClass:[NSString class]] ? labelObj : @"";

                        NSString *blob = [NSString stringWithFormat:@"%@ %@ %@", svc, acct, label];
                        if (!ACNameMatches(blob, deep)) continue;

                        if (dry) {
                            ACLogFmt(@"[预演] 会删除钥匙串项 %@ / %@", svc, acct);
                            removed++;
                            continue;
                        }

                        // 必须至少有一个标识字段，否则可能误删整类条目
                        if (svc.length == 0 && acct.length == 0) {
                            ACLogFmt(@"跳过无标识的钥匙串项（防止误删）");
                            continue;
                        }

                        NSMutableDictionary *del = [NSMutableDictionary dictionary];
                        del[(__bridge id)kSecClass] = cls;
                        if (svc.length)  del[(__bridge id)kSecAttrService] = svc;
                        if (acct.length) del[(__bridge id)kSecAttrAccount] = acct;

                        OSStatus ds = SecItemDelete((__bridge CFDictionaryRef)del);
                        if (ds == errSecSuccess) {
                            removed++;
                            ACLogFmt(@"删除钥匙串项 %@ / %@", svc, acct);
                        }
                    }
                }
            } @catch (NSException *e) {
                ACLogFmt(@"钥匙串清理异常（已忽略）：%@", e.reason ?: @"unknown");
            }
        }
    }

    ACLogFmt(@"钥匙串清理完成：%@ %lu 项", dry ? @"预演命中" : @"删除", (unsigned long)removed);
}

#pragma mark 崩溃熔断

/// 上次若标记了 inProgress 但没走完，说明那次清理中途挂了（通常是 App 被杀 / 崩溃）
+ (NSUInteger)bumpCrashGuard {
    @try {
        NSMutableDictionary *st = [ACPrefs state];
        NSUInteger fail = [st[kACKeyFailCount] unsignedIntegerValue];
        BOOL inProgress = [st[kACKeyInProgress] boolValue];

        if (inProgress) {
            fail += 1;
            ACLogFmt(@"上次清理未正常结束，累计异常次数 %lu", (unsigned long)fail);
        } else {
            fail = 0;
        }

        st[kACKeyFailCount] = @(fail);
        st[kACKeyInProgress] = @YES;
        [ACPrefs saveState:st];
        return fail;
    } @catch (__unused NSException *e) {
        return 0;
    }
}

+ (void)finishCrashGuard {
    @try {
        NSMutableDictionary *st = [ACPrefs state];
        st[kACKeyInProgress] = @NO;
        st[kACKeyFailCount] = @0;
        [ACPrefs saveState:st];
    } @catch (__unused NSException *e) {}
}

@end
