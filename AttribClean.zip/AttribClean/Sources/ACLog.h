// ACLog.h — 轻量日志（写入 App 容器，供设置 App 展示）
#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif

void ACLogReset(void);
void ACLogFmt(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
/// 把本次日志落盘到状态文件
void ACLogFlush(void);

#ifdef __cplusplus
}
#endif
