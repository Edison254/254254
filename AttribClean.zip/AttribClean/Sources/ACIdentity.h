// ACIdentity.h — IDFA / IDFV 虚拟标识
#import <Foundation/Foundation.h>

@interface ACIdentity : NSObject

/// 当前 App 应返回的 IDFA（全局统一，写死在配置里，未配置则返回 nil）
+ (NSString *)fakeIDFA;

/// 当前 App 应返回的 IDFV（按 vendor 分组，每个 vendor 一个稳定值）
+ (NSString *)fakeIDFVForBundleID:(NSString *)bundleID;

/// 生成一个新的随机 IDFA 字符串
+ (NSString *)generateIDFA;

/// 生成一个新的随机 IDFV 字符串
+ (NSString *)generateIDFV;

/// bundleID 对应的 vendor 前缀（用于 IDFV 分组）
+ (NSString *)vendorKeyForBundleID:(NSString *)bundleID;

/// 清缓存
+ (void)invalidateCache;

@end
