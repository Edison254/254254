// ACLog.m — 轻量日志
#import "ACLog.h"
#import "ACCommon.h"
#import "ACPrefs.h"

static NSMutableArray<NSString *> *gLines = nil;
static dispatch_queue_t gLogQueue = nil;

static void ACLogInitOnce(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gLogQueue = dispatch_queue_create("com.zaka.attribclean.log", DISPATCH_QUEUE_SERIAL);
        gLines = [NSMutableArray arrayWithCapacity:128];
    });
}

void ACLogReset(void) {
    ACLogInitOnce();
    dispatch_sync(gLogQueue, ^{
        [gLines removeAllObjects];
    });
}

void ACLogFmt(NSString *fmt, ...) {
    if (!fmt) return;
    ACLogInitOnce();

    va_list ap;
    va_start(ap, fmt);
    NSString *line = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);

    if (!line) return;
    // 单条日志长度上限，防止意外巨量
    if (line.length > 400) {
        line = [[line substringToIndex:400] stringByAppendingString:@"…"];
    }

    dispatch_async(gLogQueue, ^{
        if (gLines.count >= 400) return;      // 上限保护
        [gLines addObject:line];
    });
}

void ACLogFlush(void) {
    ACLogInitOnce();
    dispatch_sync(gLogQueue, ^{
        @try {
            NSMutableDictionary *st = [ACPrefs state];
            st[kACKeyLastCleanLog] = [gLines copy];
            st[kACKeyLastCleanTime] = @([[NSDate date] timeIntervalSince1970]);
            [ACPrefs saveState:st];
        } @catch (__unused NSException *e) {}
    });
}
