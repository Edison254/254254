// ACPrefs.h — 配置读写
#import <Foundation/Foundation.h>

@interface ACPrefs : NSObject

/// 读取当前 App 的完整配置（容器内配置覆盖全局配置，全局覆盖默认值）
+ (NSDictionary *)currentConfig;

/// 取单个配置项
+ (BOOL)boolForKey:(NSString *)key;
+ (NSString *)stringForKey:(NSString *)key;

/// 写入当前 App 容器内的配置（tweak 内极少用到）
+ (BOOL)writeLocalConfig:(NSDictionary *)config;

/// 清缓存，强制下次重新读盘
+ (void)invalidateCache;

/// 读取当前 App 的持久状态（熔断计数等）
+ (NSMutableDictionary *)state;
+ (void)saveState:(NSDictionary *)state;

@end
