// ACPrefs.m — 配置读写
#import "ACPrefs.h"
#import "ACCommon.h"

static NSDictionary *gCfgCache = nil;
static NSTimeInterval gCfgTime = 0;
static NSMutableDictionary *gStateCache = nil;

@implementation ACPrefs

#pragma mark - 读配置

+ (NSDictionary *)currentConfig {
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (gCfgCache && (now - gCfgTime) < 2.0) {
        return gCfgCache;
    }

    @try {
        NSMutableDictionary *cfg = [ACDefaultConfig() mutableCopy];

        // 1) 全局兜底配置（跨 App）
        NSDictionary *sys = [NSDictionary dictionaryWithContentsOfFile:ACSystemPrefsPath()];
        if ([sys isKindOfClass:[NSDictionary class]] && sys.count) {
            [cfg addEntriesFromDictionary:sys];
        }

        // 2) 本 App 容器内的配置（优先级最高）
        NSDictionary *local = [NSDictionary dictionaryWithContentsOfFile:ACLocalPrefsPath()];
        if ([local isKindOfClass:[NSDictionary class]] && local.count) {
            [cfg addEntriesFromDictionary:local];
        }

        gCfgCache = [cfg copy];
        gCfgTime = now;
        return gCfgCache;
    } @catch (__unused NSException *e) {
        gCfgCache = ACDefaultConfig();
        gCfgTime = now;
        return gCfgCache;
    }
}

+ (BOOL)boolForKey:(NSString *)key {
    if (!key) return NO;
    @try {
        id v = [self currentConfig][key];
        if ([v isKindOfClass:[NSNumber class]]) return [v boolValue];
        if ([v isKindOfClass:[NSString class]]) {
            NSString *s = [(NSString *)v lowercaseString];
            return [s isEqualToString:@"1"] || [s isEqualToString:@"yes"] || [s isEqualToString:@"true"];
        }
    } @catch (__unused NSException *e) {}
    return NO;
}

+ (NSString *)stringForKey:(NSString *)key {
    if (!key) return nil;
    @try {
        id v = [self currentConfig][key];
        if ([v isKindOfClass:[NSString class]] && [(NSString *)v length]) return v;
    } @catch (__unused NSException *e) {}
    return nil;
}

+ (BOOL)writeLocalConfig:(NSDictionary *)config {
    if (![config isKindOfClass:[NSDictionary class]]) return NO;
    @try {
        NSString *path = ACLocalPrefsPath();
        NSString *dir = [path stringByDeletingLastPathComponent];
        [[NSFileManager defaultManager] createDirectoryAtPath:dir
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:NULL];
        BOOL ok = [config writeToFile:path atomically:YES];
        [self invalidateCache];
        return ok;
    } @catch (__unused NSException *e) {
        return NO;
    }
}

+ (void)invalidateCache {
    gCfgCache = nil;
    gCfgTime = 0;
}

#pragma mark - 状态（熔断 / 上次清理记录）

+ (NSMutableDictionary *)state {
    if (gStateCache) return gStateCache;
    @try {
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:ACStateFilePath()];
        gStateCache = [d isKindOfClass:[NSDictionary class]] ? [d mutableCopy] : [NSMutableDictionary dictionary];
    } @catch (__unused NSException *e) {
        gStateCache = [NSMutableDictionary dictionary];
    }
    return gStateCache;
}

+ (void)saveState:(NSDictionary *)state {
    if (![state isKindOfClass:[NSDictionary class]]) return;
    @try {
        NSString *dir = ACStateDir();
        [[NSFileManager defaultManager] createDirectoryAtPath:dir
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:NULL];
        gStateCache = [state mutableCopy];
        [state writeToFile:ACStateFilePath() atomically:YES];
    } @catch (__unused NSException *e) {}
}

@end
