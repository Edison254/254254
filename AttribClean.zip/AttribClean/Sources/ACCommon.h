// ACCommon.h — 公共定义
#ifndef AC_COMMON_H
#define AC_COMMON_H

#import <Foundation/Foundation.h>
#import <unistd.h>
#import <sys/stat.h>

#pragma mark - 配置域

#define AC_DOMAIN_NAME  @"com.zaka.attribclean"
#define AC_PREFS_FILE   @"com.zaka.attribclean.plist"

#pragma mark - 配置键

// 总开关（每 App 一份，写在目标 App 自己的容器里）
static NSString *const kACKeyEnabled        = @"enabled";

// 清理项开关
static NSString *const kACKeyCleanIDFA      = @"cleanIDFA";
static NSString *const kACKeyCleanIDFV      = @"cleanIDFV";
static NSString *const kACKeyCleanATT       = @"cleanATT";
static NSString *const kACKeyCleanFiles     = @"cleanFiles";
static NSString *const kACKeyCleanPrefs     = @"cleanPrefs";
static NSString *const kACKeyCleanKeychain  = @"cleanKeychain";
static NSString *const kACKeyDeepClean      = @"deepClean";   // 激进模式，默认关
static NSString *const kACKeyDryRun         = @"dryRun";      // 预演模式，只记录不删

// 数据
static NSString *const kACKeyFakeIDFA       = @"fakeIDFA";
static NSString *const kACKeyIDFVMap        = @"idfvMap";
static NSString *const kACKeyLastCleanTime  = @"lastCleanTime";
static NSString *const kACKeyLastCleanLog   = @"lastCleanLog";

// 熔断
static NSString *const kACKeyFailCount      = @"failCount";
static NSString *const kACKeyInProgress     = @"inProgress";

#pragma mark - 运行环境判断

/// 是否 rootless（Dopamine / palera1n / 多数 iOS 15-18 越狱）
static inline BOOL ACIsRootless(void) {
    static int cached = -1;
    if (cached < 0) {
        cached = (access("/var/jb", F_OK) == 0) ? 1 : 0;
    }
    return cached == 1;
}

/// 全局（跨 App）配置文件路径，仅作兜底
static inline NSString *ACSystemPrefsPath(void) {
    if (ACIsRootless()) {
        return @"/var/jb/var/mobile/Library/Preferences/com.zaka.attribclean.plist";
    }
    return @"/var/mobile/Library/Preferences/com.zaka.attribclean.plist";
}

/// 当前进程自己的配置文件路径（App 容器内，沙盒内可读可写）
static inline NSString *ACLocalPrefsPath(void) {
    return [NSHomeDirectory() stringByAppendingPathComponent:
            @"Library/Preferences/com.zaka.attribclean.plist"];
}

#pragma mark - 日志路径

/// 当前进程容器内的状态目录
static inline NSString *ACStateDir(void) {
    return [NSHomeDirectory() stringByAppendingPathComponent:
            @"Library/Caches/com.zaka.attribclean"];
}

static inline NSString *ACStateFilePath(void) {
    return [ACStateDir() stringByAppendingPathComponent:@"state.plist"];
}

#pragma mark - 小工具

static inline BOOL ACFileExists(NSString *path) {
    if (!path) return NO;
    return [[NSFileManager defaultManager] fileExistsAtPath:path];
}

static inline BOOL ACIsUserApp(void) {
    NSString *bid = [[NSBundle mainBundle] bundleIdentifier];
    if (!bid || bid.length == 0) return NO;
    if ([bid hasPrefix:@"com.apple."]) return NO;

    NSString *bundlePath = [[NSBundle mainBundle] bundlePath];
    if (!bundlePath) return NO;

    // 用户 App 的安装路径
    if ([bundlePath hasPrefix:@"/var/containers/Bundle/Application/"]) return YES;
    if ([bundlePath hasPrefix:@"/private/var/containers/Bundle/Application/"]) return YES;

    return NO;
}

#pragma mark - 默认值

static inline NSDictionary *ACDefaultConfig(void) {
    return @{
        kACKeyEnabled       : @NO,
        kACKeyCleanIDFA     : @YES,
        kACKeyCleanIDFV     : @YES,
        kACKeyCleanATT      : @YES,
        kACKeyCleanFiles    : @YES,
        kACKeyCleanPrefs    : @YES,
        kACKeyCleanKeychain : @YES,
        kACKeyDeepClean     : @NO,
        kACKeyDryRun        : @NO,
    };
}

#endif /* AC_COMMON_H */
