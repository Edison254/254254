#!/usr/bin/env python3
# 生成设置 App 的图标（改配色就改这里的两个颜色）
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "prefsapp", "Resources")

BG_TOP = (26, 34, 56)      # 顶部深蓝
BG_BOT = (12, 16, 28)      # 底部近黑
ACCENT = (86, 227, 190)    # 青色

def make(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # 竖向渐变底
    for y in range(size):
        t = y / max(1, size - 1)
        r = int(BG_TOP[0] + (BG_BOT[0] - BG_TOP[0]) * t)
        g = int(BG_TOP[1] + (BG_BOT[1] - BG_TOP[1]) * t)
        b = int(BG_TOP[2] + (BG_BOT[2] - BG_TOP[2]) * t)
        d.line([(0, y), (size, y)], fill=(r, g, b, 255))

    # 圆角遮罩
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, size - 1, size - 1], radius=int(size * 0.22), fill=255)
    img.putalpha(mask)

    # 中心刷新环
    pad = int(size * 0.26)
    w = max(2, int(size * 0.075))
    d.arc([pad, pad, size - pad, size - pad], start=-55, end=245, fill=ACCENT + (255,), width=w)

    # 箭头
    cx, cy = size * 0.5, pad + (size - 2 * pad) * 0.5
    r = (size - 2 * pad) * 0.5
    import math
    ang = math.radians(-55)
    px = cx + r * math.cos(ang)
    py = cy + r * math.sin(ang)
    s = size * 0.095
    d.polygon([(px + s, py - s * 0.25), (px - s * 0.15, py - s * 1.0), (px - s * 0.15, py + s * 0.55)],
              fill=ACCENT + (255,))

    # 中心点
    dr = size * 0.045
    d.ellipse([cx - dr, cy - dr, cx + dr, cy + dr], fill=(255, 255, 255, 210))

    return img

def main():
    os.makedirs(OUT, exist_ok=True)
    targets = {
        "AppIcon60x60@2x.png": 120,
        "AppIcon60x60@3x.png": 180,
        "AppIcon76x76@2x.png": 152,
        "AppIcon40x40@2x.png": 80,
        "AppIcon29x29@2x.png": 58,
    }
    for name, size in targets.items():
        img = make(size)
        img.save(os.path.join(OUT, name))
        print("wrote", name, size)

if __name__ == "__main__":
    main()
